export default (uid, name, photoUrl, email, lastSignInTime) => ({
  uid,
  name,
  photoUrl,
  email,
  lastSignInTime,
});
