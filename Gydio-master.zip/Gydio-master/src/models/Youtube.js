export default (videoId, user, creationDate = Date.now()) => ({
  videoId,
  user,
  creationDate,
});
