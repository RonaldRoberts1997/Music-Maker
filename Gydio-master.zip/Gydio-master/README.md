# Gydio
Your favorite place for Gaming/Cartoon related Music, Themes and Soundtracks.

# Upcoming

* Creating/using a Music identifier e.g ShazamAPIs.

# Live
https://mahmoudzakaria90.github.io/Gydio/dist/#/

# Development

## Project setup
```
yarn install
```

### Compiles and hot-reloads for development
```
yarn run serve
```

### Compiles and minifies for production
```
yarn run build
```

### Lints and fixes files
```
yarn run lint
```
